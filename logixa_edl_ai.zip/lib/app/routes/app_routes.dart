part of 'app_pages.dart';
// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

abstract class Routes {
  Routes._();

  static const home = _Paths.home;
  static const workSpace = _Paths.workSpace;
  static const chatPage = _Paths.chatPage;
  static const dataCenter = _Paths.dataCenter;
  static const settings = _Paths.settings;
}

abstract class _Paths {
  _Paths._();

  static const home = '/home';
  static const workSpace = '/work-space';
  static const chatPage = '/chat-page';
  static const dataCenter = '/data-center';
  static const settings = '/settings';
}
