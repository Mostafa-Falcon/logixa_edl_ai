class MemoryStatusSummary {
  final String dbPath;
  final int conversations;
  final int messages;
  final int memoryItems;
  final int experts;
  final int workspaceSessions;

  const MemoryStatusSummary({
    required this.dbPath,
    required this.conversations,
    required this.messages,
    required this.memoryItems,
    required this.experts,
    required this.workspaceSessions,
  });

  factory MemoryStatusSummary.empty() {
    return const MemoryStatusSummary(
      dbPath: '--',
      conversations: 0,
      messages: 0,
      memoryItems: 0,
      experts: 0,
      workspaceSessions: 0,
    );
  }

  factory MemoryStatusSummary.fromJson(Map<String, dynamic> json) {
    return MemoryStatusSummary(
      dbPath: _asString(json['db_path'], fallback: '--'),
      conversations: _asInt(json['conversations']),
      messages: _asInt(json['messages']),
      memoryItems: _asInt(json['memory_items']),
      experts: _asInt(json['experts']),
      workspaceSessions: _asInt(json['workspace_sessions']),
    );
  }
}

class MemoryConversationSummary {
  final String id;
  final String title;
  final String? workspacePath;
  final String? modelProfileId;
  final String? systemPromptPreview;
  final int createdAt;
  final int updatedAt;

  const MemoryConversationSummary({
    required this.id,
    required this.title,
    this.workspacePath,
    this.modelProfileId,
    this.systemPromptPreview,
    required this.createdAt,
    required this.updatedAt,
  });

  factory MemoryConversationSummary.fromJson(Map<String, dynamic> json) {
    return MemoryConversationSummary(
      id: _asString(json['id'], fallback: ''),
      title: _asString(json['title'], fallback: 'محادثة بدون عنوان'),
      workspacePath: _asNullableString(json['workspace_path']),
      modelProfileId: _asNullableString(json['model_profile_id']),
      systemPromptPreview: _asNullableString(json['system_prompt_preview']),
      createdAt: _asInt(json['created_at']),
      updatedAt: _asInt(json['updated_at']),
    );
  }
}

class MemoryMessageSummary {
  final String id;
  final String conversationId;
  final String role;
  final String content;
  final String? modelProfileId;
  final Map<String, dynamic>? metadata;
  final int createdAt;

  const MemoryMessageSummary({
    required this.id,
    required this.conversationId,
    required this.role,
    required this.content,
    this.modelProfileId,
    this.metadata,
    required this.createdAt,
  });

  factory MemoryMessageSummary.fromJson(Map<String, dynamic> json) {
    return MemoryMessageSummary(
      id: _asString(json['id'], fallback: ''),
      conversationId: _asString(json['conversation_id'], fallback: ''),
      role: _asString(json['role'], fallback: 'unknown'),
      content: _asString(json['content'], fallback: ''),
      modelProfileId: _asNullableString(json['model_profile_id']),
      metadata: _asNullableMap(json['metadata']),
      createdAt: _asInt(json['created_at']),
    );
  }
}

class MemoryItemSummary {
  final String id;
  final String key;
  final String value;
  final String? source;
  final List<String> tags;
  final int updatedAt;

  const MemoryItemSummary({
    required this.id,
    required this.key,
    required this.value,
    this.source,
    required this.tags,
    required this.updatedAt,
  });

  factory MemoryItemSummary.fromJson(Map<String, dynamic> json) {
    return MemoryItemSummary(
      id: _asString(json['id'], fallback: ''),
      key: _asString(json['key'], fallback: 'memory_item'),
      value: _asString(json['value'], fallback: ''),
      source: _asNullableString(json['source']),
      tags: _asStringList(json['tags']),
      updatedAt: _asInt(json['updated_at']),
    );
  }
}

class MemoryExpertSummary {
  final String id;
  final String name;
  final String systemPrompt;
  final String? modelProfileId;
  final int updatedAt;

  const MemoryExpertSummary({
    required this.id,
    required this.name,
    required this.systemPrompt,
    this.modelProfileId,
    required this.updatedAt,
  });

  factory MemoryExpertSummary.fromJson(Map<String, dynamic> json) {
    return MemoryExpertSummary(
      id: _asString(json['id'], fallback: ''),
      name: _asString(json['name'], fallback: 'خبير بدون اسم'),
      systemPrompt: _asString(json['system_prompt'], fallback: ''),
      modelProfileId: _asNullableString(json['model_profile_id']),
      updatedAt: _asInt(json['updated_at']),
    );
  }
}

class MemoryWorkspaceSessionSummary {
  final String id;
  final String workspacePath;
  final String? workspaceName;
  final String? activeFile;
  final Map<String, dynamic>? metadata;
  final int updatedAt;

  const MemoryWorkspaceSessionSummary({
    required this.id,
    required this.workspacePath,
    this.workspaceName,
    this.activeFile,
    this.metadata,
    required this.updatedAt,
  });

  int get openedFileCount {
    final value = metadata?['opened_file_count'];
    if (value is int) return value;
    if (value is num) return value.toInt();
    if (value is String) return int.tryParse(value.trim()) ?? 0;
    final openedFiles = metadata?['opened_files'];
    if (openedFiles is List) return openedFiles.length;
    return 0;
  }

  String get syncEvent {
    final value = metadata?['event'];
    if (value is String && value.trim().isNotEmpty) return value.trim();
    return 'workspace_session';
  }

  factory MemoryWorkspaceSessionSummary.fromJson(Map<String, dynamic> json) {
    return MemoryWorkspaceSessionSummary(
      id: _asString(json['id'], fallback: ''),
      workspacePath: _asString(json['workspace_path'], fallback: '--'),
      workspaceName: _asNullableString(json['workspace_name']),
      activeFile: _asNullableString(json['active_file']),
      metadata: _asNullableMap(json['metadata']),
      updatedAt: _asInt(json['updated_at']),
    );
  }
}

class SelectedModelProfileSnapshot {
  final String? profileId;
  final Map<String, dynamic>? profile;
  final int? updatedAt;

  const SelectedModelProfileSnapshot({
    this.profileId,
    this.profile,
    this.updatedAt,
  });

  factory SelectedModelProfileSnapshot.empty() {
    return const SelectedModelProfileSnapshot();
  }

  factory SelectedModelProfileSnapshot.fromJson(Map<String, dynamic> json) {
    return SelectedModelProfileSnapshot(
      profileId: _asNullableString(json['profile_id']),
      profile: _asNullableMap(json['profile']),
      updatedAt: _asNullableInt(json['updated_at']),
    );
  }

  String get displayName {
    final profileMap = profile;
    if (profileMap == null) return profileId ?? 'لا يوجد Snapshot محفوظ';

    final name = _asNullableString(profileMap['name']);
    if (name != null) return name;
    return profileId ?? 'بروفايل بدون اسم';
  }
}

class MemoryDashboardSnapshot {
  final MemoryStatusSummary status;
  final List<MemoryConversationSummary> conversations;
  final List<MemoryMessageSummary> messages;
  final List<MemoryItemSummary> memoryItems;
  final List<MemoryExpertSummary> experts;
  final List<MemoryWorkspaceSessionSummary> workspaceSessions;
  final SelectedModelProfileSnapshot selectedModelProfile;

  const MemoryDashboardSnapshot({
    required this.status,
    required this.conversations,
    required this.messages,
    required this.memoryItems,
    required this.experts,
    required this.workspaceSessions,
    required this.selectedModelProfile,
  });

  factory MemoryDashboardSnapshot.empty() {
    return MemoryDashboardSnapshot(
      status: MemoryStatusSummary.empty(),
      conversations: const [],
      messages: const [],
      memoryItems: const [],
      experts: const [],
      workspaceSessions: const [],
      selectedModelProfile: SelectedModelProfileSnapshot.empty(),
    );
  }
}

class EngineMemoryDashboardResult {
  final bool ok;
  final String message;
  final MemoryDashboardSnapshot snapshot;

  const EngineMemoryDashboardResult({
    required this.ok,
    required this.message,
    required this.snapshot,
  });

  factory EngineMemoryDashboardResult.success(
    MemoryDashboardSnapshot snapshot,
  ) {
    return EngineMemoryDashboardResult(
      ok: true,
      message: 'تم تحميل مركز البيانات من Rust Memory.',
      snapshot: snapshot,
    );
  }

  factory EngineMemoryDashboardResult.failed(String message) {
    return EngineMemoryDashboardResult(
      ok: false,
      message: message,
      snapshot: MemoryDashboardSnapshot.empty(),
    );
  }
}

Map<String, dynamic> _asMap(dynamic value) {
  if (value is Map<String, dynamic>) return value;
  if (value is Map) return Map<String, dynamic>.from(value);
  return <String, dynamic>{};
}

Map<String, dynamic>? _asNullableMap(dynamic value) {
  if (value == null) return null;
  final map = _asMap(value);
  return map.isEmpty ? null : map;
}

String _asString(dynamic value, {required String fallback}) {
  if (value is String && value.trim().isNotEmpty) return value.trim();
  return fallback;
}

String? _asNullableString(dynamic value) {
  if (value is String && value.trim().isNotEmpty) return value.trim();
  return null;
}

int _asInt(dynamic value) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  if (value is String) return int.tryParse(value.trim()) ?? 0;
  return 0;
}

int? _asNullableInt(dynamic value) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  if (value is String) return int.tryParse(value.trim());
  return null;
}

List<String> _asStringList(dynamic value) {
  if (value is List) {
    return value
        .map((item) => item.toString().trim())
        .where((item) => item.isNotEmpty)
        .toList(growable: false);
  }
  return const [];
}
