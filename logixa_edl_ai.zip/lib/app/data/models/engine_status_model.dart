class EngineStatusModel {
  final bool isOnline;
  final bool isChecking;
  final String service;
  final String version;
  final String statusMessage;
  final String? errorMessage;
  final String? configPath;
  final String? memoryDbPath;
  final int? uptimeSeconds;
  final bool engineRunning;
  final bool localModelEnabled;
  final bool modelLoaded;
  final String runtimeStage;
  final String? activeModelProfileId;

  const EngineStatusModel({
    required this.isOnline,
    required this.isChecking,
    required this.service,
    required this.version,
    required this.statusMessage,
    required this.errorMessage,
    required this.configPath,
    required this.memoryDbPath,
    required this.uptimeSeconds,
    required this.engineRunning,
    required this.localModelEnabled,
    required this.modelLoaded,
    required this.runtimeStage,
    required this.activeModelProfileId,
  });

  factory EngineStatusModel.initial() {
    return const EngineStatusModel(
      isOnline: false,
      isChecking: false,
      service: 'logixa_engine',
      version: '-',
      statusMessage: 'لم يتم فحص المحرك بعد',
      errorMessage: null,
      configPath: null,
      memoryDbPath: null,
      uptimeSeconds: null,
      engineRunning: false,
      localModelEnabled: false,
      modelLoaded: false,
      runtimeStage: 'unknown',
      activeModelProfileId: null,
    );
  }

  EngineStatusModel copyWith({
    bool? isOnline,
    bool? isChecking,
    String? service,
    String? version,
    String? statusMessage,
    Object? errorMessage = _sentinel,
    Object? configPath = _sentinel,
    Object? memoryDbPath = _sentinel,
    Object? uptimeSeconds = _sentinel,
    bool? engineRunning,
    bool? localModelEnabled,
    bool? modelLoaded,
    String? runtimeStage,
    Object? activeModelProfileId = _sentinel,
  }) {
    return EngineStatusModel(
      isOnline: isOnline ?? this.isOnline,
      isChecking: isChecking ?? this.isChecking,
      service: service ?? this.service,
      version: version ?? this.version,
      statusMessage: statusMessage ?? this.statusMessage,
      errorMessage: identical(errorMessage, _sentinel)
          ? this.errorMessage
          : errorMessage as String?,
      configPath: identical(configPath, _sentinel)
          ? this.configPath
          : configPath as String?,
      memoryDbPath: identical(memoryDbPath, _sentinel)
          ? this.memoryDbPath
          : memoryDbPath as String?,
      uptimeSeconds: identical(uptimeSeconds, _sentinel)
          ? this.uptimeSeconds
          : uptimeSeconds as int?,
      engineRunning: engineRunning ?? this.engineRunning,
      localModelEnabled: localModelEnabled ?? this.localModelEnabled,
      modelLoaded: modelLoaded ?? this.modelLoaded,
      runtimeStage: runtimeStage ?? this.runtimeStage,
      activeModelProfileId: identical(activeModelProfileId, _sentinel)
          ? this.activeModelProfileId
          : activeModelProfileId as String?,
    );
  }

  static const Object _sentinel = Object();
}
