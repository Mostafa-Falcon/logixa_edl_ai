class ModelProfileModel {
  final String id;
  final String name;
  final String modelPath;
  final int contextSize;
  final int threads;
  final int batchSize;
  final int maxTokens;
  final double temperature;
  final double topP;
  final int topK;
  final double repeatPenalty;
  final double presencePenalty;
  final String promptTemplate;
  final String modelRole;
  final String loadPolicy;
  final String ramPolicy;
  final bool keepModelLoaded;
  final bool unloadAfterResponse;
  final bool isActive;

  const ModelProfileModel({
    required this.id,
    required this.name,
    required this.modelPath,
    required this.contextSize,
    required this.threads,
    required this.batchSize,
    required this.maxTokens,
    required this.temperature,
    required this.topP,
    required this.topK,
    required this.repeatPenalty,
    required this.presencePenalty,
    required this.promptTemplate,
    required this.modelRole,
    required this.loadPolicy,
    required this.ramPolicy,
    required this.keepModelLoaded,
    required this.unloadAfterResponse,
    required this.isActive,
  });

  static const String gemmaPromptTemplate =
      '<start_of_turn>user\n{system_prompt}\n\n{user_prompt}<end_of_turn>\n<start_of_turn>model';

  static const String gemma4bFastPath =
      'models/gemma3_abliterated_v2/gemma-3-4b-it-abliterated-v2.q4_k_m.gguf';

  static const String gemma12bQualityPath =
      'models/gemma3_abliterated_v2/gemma-3-12b-it-abliterated-v2.q4_k_m.gguf';

  factory ModelProfileModel.defaultLocal() {
    return const ModelProfileModel(
      id: 'default_local_model',
      name: 'Default Local Model',
      modelPath: '',
      contextSize: 2048,
      threads: 4,
      batchSize: 256,
      maxTokens: 512,
      temperature: 1.0,
      topP: 0.95,
      topK: 64,
      repeatPenalty: 1.10,
      presencePenalty: 0.10,
      promptTemplate: gemmaPromptTemplate,
      modelRole: 'fast',
      loadPolicy: 'on_demand',
      ramPolicy: 'conservative',
      keepModelLoaded: false,
      unloadAfterResponse: true,
      isActive: true,
    );
  }

  factory ModelProfileModel.gemma4bFast() {
    return const ModelProfileModel(
      id: 'gemma_3_4b_abliterated_fast',
      name: 'Gemma 3 4B Fast',
      modelPath: gemma4bFastPath,
      contextSize: 4096,
      threads: 6,
      batchSize: 256,
      maxTokens: 512,
      temperature: 1.0,
      topP: 0.95,
      topK: 64,
      repeatPenalty: 1.10,
      presencePenalty: 0.10,
      promptTemplate: gemmaPromptTemplate,
      modelRole: 'fast',
      loadPolicy: 'on_demand',
      ramPolicy: 'conservative',
      keepModelLoaded: false,
      unloadAfterResponse: true,
      isActive: true,
    );
  }

  factory ModelProfileModel.gemma12bQuality() {
    return const ModelProfileModel(
      id: 'gemma_3_12b_abliterated_quality',
      name: 'Gemma 3 12B Quality',
      modelPath: gemma12bQualityPath,
      contextSize: 4096,
      threads: 6,
      batchSize: 128,
      maxTokens: 768,
      temperature: 1.0,
      topP: 0.95,
      topK: 64,
      repeatPenalty: 1.10,
      presencePenalty: 0.10,
      promptTemplate: gemmaPromptTemplate,
      modelRole: 'quality',
      loadPolicy: 'on_demand',
      ramPolicy: 'conservative',
      keepModelLoaded: false,
      unloadAfterResponse: true,
      isActive: true,
    );
  }

  factory ModelProfileModel.fromJson(Map<String, dynamic> json) {
    final fallback = ModelProfileModel.defaultLocal();

    return ModelProfileModel(
      id: _readString(json['id'], fallback.id),
      name: _readString(json['name'], fallback.name),
      modelPath: _readString(json['model_path'], fallback.modelPath),
      contextSize: _readInt(json['context_size'], fallback.contextSize),
      threads: _readInt(json['threads'], fallback.threads),
      batchSize: _readInt(json['batch_size'], fallback.batchSize),
      maxTokens: _readInt(json['max_tokens'], fallback.maxTokens),
      temperature: _readDouble(json['temperature'], fallback.temperature),
      topP: _readDouble(json['top_p'], fallback.topP),
      topK: _readInt(json['top_k'], fallback.topK),
      repeatPenalty: _readDouble(json['repeat_penalty'], fallback.repeatPenalty),
      presencePenalty: _readDouble(json['presence_penalty'], fallback.presencePenalty),
      promptTemplate: _readString(json['prompt_template'], fallback.promptTemplate),
      modelRole: _readString(json['model_role'], fallback.modelRole),
      loadPolicy: _readString(json['load_policy'], fallback.loadPolicy),
      ramPolicy: _readString(json['ram_policy'], fallback.ramPolicy),
      keepModelLoaded: _readBool(
        json['keep_model_loaded'],
        fallback.keepModelLoaded,
      ),
      unloadAfterResponse: _readBool(
        json['unload_after_response'],
        fallback.unloadAfterResponse,
      ),
      isActive: _readBool(json['is_active'], fallback.isActive),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'model_path': modelPath,
      'context_size': contextSize,
      'threads': threads,
      'batch_size': batchSize,
      'max_tokens': maxTokens,
      'temperature': temperature,
      'top_p': topP,
      'top_k': topK,
      'repeat_penalty': repeatPenalty,
      'presence_penalty': presencePenalty,
      'prompt_template': promptTemplate,
      'model_role': modelRole,
      'load_policy': loadPolicy,
      'ram_policy': ramPolicy,
      'keep_model_loaded': keepModelLoaded,
      'unload_after_response': unloadAfterResponse,
      'is_active': isActive,
    };
  }

  ModelProfileModel copyWith({
    String? id,
    String? name,
    String? modelPath,
    int? contextSize,
    int? threads,
    int? batchSize,
    int? maxTokens,
    double? temperature,
    double? topP,
    int? topK,
    double? repeatPenalty,
    double? presencePenalty,
    String? promptTemplate,
    String? modelRole,
    String? loadPolicy,
    String? ramPolicy,
    bool? keepModelLoaded,
    bool? unloadAfterResponse,
    bool? isActive,
  }) {
    return ModelProfileModel(
      id: id ?? this.id,
      name: name ?? this.name,
      modelPath: modelPath ?? this.modelPath,
      contextSize: contextSize ?? this.contextSize,
      threads: threads ?? this.threads,
      batchSize: batchSize ?? this.batchSize,
      maxTokens: maxTokens ?? this.maxTokens,
      temperature: temperature ?? this.temperature,
      topP: topP ?? this.topP,
      topK: topK ?? this.topK,
      repeatPenalty: repeatPenalty ?? this.repeatPenalty,
      presencePenalty: presencePenalty ?? this.presencePenalty,
      promptTemplate: promptTemplate ?? this.promptTemplate,
      modelRole: modelRole ?? this.modelRole,
      loadPolicy: loadPolicy ?? this.loadPolicy,
      ramPolicy: ramPolicy ?? this.ramPolicy,
      keepModelLoaded: keepModelLoaded ?? this.keepModelLoaded,
      unloadAfterResponse: unloadAfterResponse ?? this.unloadAfterResponse,
      isActive: isActive ?? this.isActive,
    );
  }

  static String _readString(dynamic value, String fallback) {
    if (value is String && value.trim().isNotEmpty) return value.trim();
    return fallback;
  }

  static int _readInt(dynamic value, int fallback) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    if (value is String) return int.tryParse(value.trim()) ?? fallback;
    return fallback;
  }

  static double _readDouble(dynamic value, double fallback) {
    if (value is double) return value;
    if (value is num) return value.toDouble();
    if (value is String) return double.tryParse(value.trim()) ?? fallback;
    return fallback;
  }

  static bool _readBool(dynamic value, bool fallback) {
    if (value is bool) return value;
    if (value is String) {
      final normalized = value.trim().toLowerCase();
      if (normalized == 'true') return true;
      if (normalized == 'false') return false;
    }
    return fallback;
  }
}
