class NewWorkspaceRequest {
  final String name;
  final String parentPath;

  const NewWorkspaceRequest({
    required this.name,
    required this.parentPath,
  });
}
