class OpenedFileModel {
  final String name;
  final String path;
  final String relativePath;
  final String content;
  final String sizeLabel;

  const OpenedFileModel({
    required this.name,
    required this.path,
    required this.relativePath,
    required this.content,
    required this.sizeLabel,
  });

  OpenedFileModel copyWith({
    String? name,
    String? path,
    String? relativePath,
    String? content,
    String? sizeLabel,
  }) {
    return OpenedFileModel(
      name: name ?? this.name,
      path: path ?? this.path,
      relativePath: relativePath ?? this.relativePath,
      content: content ?? this.content,
      sizeLabel: sizeLabel ?? this.sizeLabel,
    );
  }
}
