enum ChatMessageRole { system, user, assistant }

class ChatMessageModel {
  final String id;
  final ChatMessageRole role;
  final String content;
  final DateTime createdAt;
  final String? modelProfileId;
  final String? runtimeStage;

  const ChatMessageModel({
    required this.id,
    required this.role,
    required this.content,
    required this.createdAt,
    this.modelProfileId,
    this.runtimeStage,
  });

  bool get isUser => role == ChatMessageRole.user;
  bool get isAssistant => role == ChatMessageRole.assistant;
  bool get isSystem => role == ChatMessageRole.system;

  String get roleLabel {
    switch (role) {
      case ChatMessageRole.user:
        return 'مصطفى';
      case ChatMessageRole.assistant:
        return 'Logixa Runtime';
      case ChatMessageRole.system:
        return 'System';
    }
  }
}
