import 'package:flutter/material.dart';

class SidebarItemModel {
  final String label;
  final IconData icon;

  const SidebarItemModel({
    required this.label,
    required this.icon,
  });
}
