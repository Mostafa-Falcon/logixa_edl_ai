import 'package:flutter/material.dart';

class WorkspaceModel {
  final String name;
  final String path;
  final IconData icon;

  const WorkspaceModel({
    required this.name,
    required this.path,
    this.icon = Icons.folder_rounded,
  });

  WorkspaceModel copyWith({
    String? name,
    String? path,
    IconData? icon,
  }) {
    return WorkspaceModel(
      name: name ?? this.name,
      path: path ?? this.path,
      icon: icon ?? this.icon,
    );
  }

  factory WorkspaceModel.fromJson(Map<String, dynamic> json) {
    return WorkspaceModel(
      name: json['name'] as String? ?? '',
      path: json['path'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'path': path,
    };
  }
}
