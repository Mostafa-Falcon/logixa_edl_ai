import 'package:flutter/material.dart';

enum QuickActionType { newWorkspace, openFolder, localModel, dataCenter }

class QuickActionModel {
  final QuickActionType type;
  final String title;
  final String subtitle;
  final IconData icon;
  final LinearGradient gradient;

  const QuickActionModel({
    required this.type,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.gradient,
  });
}
