class WorkspaceFileItemModel {
  final String name;
  final String path;
  final String relativePath;
  final bool isDirectory;
  final int depth;
  final int? sizeBytes;
  final DateTime? modifiedAt;

  const WorkspaceFileItemModel({
    required this.name,
    required this.path,
    required this.relativePath,
    required this.isDirectory,
    required this.depth,
    this.sizeBytes,
    this.modifiedAt,
  });
}
